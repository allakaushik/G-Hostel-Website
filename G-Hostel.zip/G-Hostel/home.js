document.addEventListener('DOMContentLoaded', function () {
    const welcomeText = document.querySelector('.welcome-text');
    welcomeText.classList.add('show');
});
